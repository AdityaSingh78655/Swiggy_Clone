import {SafeAreaView, View} from 'react-native';
import React from 'react';
import TabNavigation from './src/navigation/TabNavigation';
import {SafeAreaProvider} from 'react-native-safe-area-context';
import {Provider} from 'react-redux';
import Store from './src/redux/Store';

const App = () => {
  return (
    <Provider store={Store}>
      <SafeAreaProvider>
        <TabNavigation />
      </SafeAreaProvider>
    </Provider>
  );
};

export default App;
