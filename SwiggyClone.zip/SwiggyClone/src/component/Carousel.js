import {View, Text} from 'react-native';
import React from 'react';
import {SliderBox} from 'react-native-image-slider-box';

const Carousel = () => {
  const images = [
    'https://cdn.grabon.in/gograbon/images/web-images/uploads/1658919135375/swiggy-coupons.jpg',
    'https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_508,h_320,c_fill/mfz2zorpe8in1noybhzo',
    'https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_508,h_320,c_fill/lhnwo9ezxo7mpkpvtdcy',
  ];

  return (
    <View style={{}}>
      <SliderBox
        images={images}
        autoPlay={false}
        circleLoop
        paginationBoxVerticalPadding={20}
        sliderBoxHeight={190}
        resizeMethod={'resize'}
        resizeMode={'cover'}
        dotColor="#13274F"
        inactiveDotColor="#90A4AE"
        ImageComponentStyle={{
          borderRadius: 10,
          width: '94%',
          marginTop: 10,
          alignSelf: 'center',
        }}
      />
    </View>
  );
};

export default Carousel;
