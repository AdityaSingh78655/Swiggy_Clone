export const FontFamily = {
  DancingBold: 'DancingScript-Bold',
  DancingMedium: 'DancingScript-Medium',
  DancingRegular: 'DancingScript-Regular',
  DancingSemiBold: 'DancingScript-SemiBold',
  PlayBlack: 'PlayfairDisplay-Black',
  PlayBlackItalic: 'PlayfairDisplay-BlackItalic',
  PlayBold: 'PlayfairDisplay-Bold',
  PlayItalic: 'PlayfairDisplay-Italic',
  PlaySemiBold: 'PlayfairDisplay-SemiBold',
  InterRegular: 'Inter-Regular',
};
