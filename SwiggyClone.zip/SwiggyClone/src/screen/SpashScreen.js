import {View, Image} from 'react-native';
import React from 'react';

const SpashScreen = () => {
  return (
    <View style={{backgroundColor:'white',width:'100%',height:'100%',alignItems:'center',justifyContent:'center'}}>
      <Image
        style={{height: 500, width: 400}}
        source={require('../../assets/image/swiggy.jpeg')}
        // resizeMode="contain"
      />
    </View>
  );
};

export default SpashScreen;
