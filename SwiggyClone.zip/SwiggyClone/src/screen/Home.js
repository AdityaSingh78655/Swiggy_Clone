import {View, Text, TextInput, Image, Pressable} from 'react-native';
import React from 'react';
import Carousel from '../component/Carousel';
import FoodTypes from '../component/FoodTypes';
import {ScrollView} from 'react-native-gesture-handler';
import QuickFood from '../component/QuickFood';
import hotels from '../data/Hotels';
import MenuItem from '../component/MenuItem';
import {FontFamily} from '../constents/Constents';

const Home = () => {
  const data = hotels;

  return (
    <ScrollView style={{paddingHorizontal: 10, marginTop: 10}}>
      <View
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          borderWidth: 1,
          borderRadius: 10,
        }}>
        <TextInput
          placeholder="Search for restaurant item or more"
          style={{width: 270}}
        />
        <Image
          source={require('../../assets/icons/search.png')}
          style={{
            marginRight: 10,
            width: 25,
            height: 'auto',
            tintColor: 'red',
          }}
          resizeMode="contain"
        />
      </View>
      <Carousel />
      <FoodTypes />
      <QuickFood />

      <View
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          justifyContent: 'space-evenly',
        }}>
        <Pressable
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            borderWidth: 1,
            borderColor: '#D0D0D0',
            padding: 10,
            borderRadius: 20,
            width: 80,
            justifyContent: 'center',
          }}>
          <Text style={{marginRight: 6}}>Filter</Text>
          <Image
            source={require('../../assets/icons/filter.png')}
            style={{height: 20, width: 20}}
            resizeMode="contain"
          />
        </Pressable>

        <Pressable
          style={{
            alignItems: 'center',
            borderWidth: 1,
            borderColor: '#D0D0D0',
            padding: 10,
            borderRadius: 20,
            width: 120,
            justifyContent: 'center',
          }}>
          <Text>Sort By Rating</Text>
        </Pressable>

        <Pressable
          style={{
            alignItems: 'center',
            borderWidth: 1,
            borderColor: '#D0D0D0',
            padding: 10,
            borderRadius: 20,
            width: 120,
            justifyContent: 'center',
          }}>
          <Text>Sort By Price</Text>
        </Pressable>
      </View>
      {data.map((item, index) => (
        <MenuItem key={index} item={item} />
      ))}
    </ScrollView>
  );
};

export default Home;
