import {Text, View, ScrollView, Pressable, Image} from 'react-native';
import React from 'react';
// import FontAwesome from 'react-native-vector-icons/FontAwesome';
import {useNavigation, useRoute} from '@react-navigation/native';
import {useDispatch, useSelector} from 'react-redux';
import {
  cleanCart,
  decrementQuantity,
  incrementQuantity,
} from '../redux/CartReducer';

const CartScreen = () => {
  const navigation = useNavigation();
  const route = useRoute();
  console.log(route.params);
  const cart = useSelector(state => state.cart.cart);
  const total = cart
    .map(item => item.price * item.quantity)
    .reduce((curr, prev) => curr + prev, 0);
  const dispatch = useDispatch();
  const instructions = [
    {
      id: '0',
      name: 'Avoid Ringing',
      image: require('../../assets/icons/ringing.png'),
    },
    {
      id: '1',
      name: 'Leave at the door',
      image: require('../../assets/icons/door.png'),
    },
    {
      id: '2',
      name: 'directions to reach',
      image: require('../../assets/icons/direction.png'),
    },
    {
      id: '3',
      name: 'Avoid Calling',
      image: require('../../assets/icons/call.png'),
    },
  ];
  return (
    <>
      <ScrollView>
        {total > 0 ? (
          <>
            <View
              style={{
                padding: 10,
                flexDirection: 'row',
                alignItems: 'center',
              }}>
              <Image
                source={require('../../assets/icons/back.png')}
                style={{width: 20, height: 20}}
              />
              <Text style={{fontSize: 17, fontWeight: '600', marginLeft: 3}}>
                {route.params.name}
              </Text>
            </View>

            <View
              style={{
                backgroundColor: 'white',
                padding: 15,
                borderRadius: 8,
                marginHorizontal: 10,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}>
              <Text style={{fontSize: 16, fontWeight: '500'}}>
                Ordering for Someone else ?
              </Text>
              <Text style={{fontSize: 16, fontWeight: '700', color: '#FF4500'}}>
                Add Details
              </Text>
            </View>

            <View
              style={{
                marginTop: 16,
                marginHorizontal: 15,
                backgroundColor: 'white',
                borderRadius: 12,
                padding: 14,
                marginLeft: 10,
                marginRight: 10,
              }}>
              {console.log('aditys')}
              {cart.map((item, index) => (
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginVertical: 10,
                  }}
                  key={index}>
                  <Text style={{width: 100, fontSize: 16, fontWeight: '600'}}>
                    {item.name}
                  </Text>

                  <Pressable
                    style={{
                      flexDirection: 'row',
                      paddingHorizontal: 10,
                      paddingVertical: 5,
                      alignItems: 'center',
                      borderColor: '#BEBEBE',
                      borderWidth: 0.5,
                      borderRadius: 10,
                    }}>
                    <Pressable
                      onPress={() => {
                        dispatch(decrementQuantity(item));
                      }}>
                      <Text
                        style={{
                          fontSize: 20,
                          color: 'green',
                          paddingHorizontal: 6,
                          fontWeight: '600',
                        }}>
                        -
                      </Text>
                    </Pressable>
                    {console.log('aditys3')}
                    <Pressable>
                      <Text
                        style={{
                          fontSize: 19,
                          color: 'green',
                          paddingHorizontal: 8,
                          fontWeight: '600',
                        }}>
                        {item.quantity}
                      </Text>
                    </Pressable>
                    {console.log('aditys4')}
                    <Pressable
                      onPress={() => {
                        dispatch(incrementQuantity(item));
                      }}>
                      <Text
                        style={{
                          fontSize: 20,
                          color: 'green',
                          paddingHorizontal: 6,
                          fontWeight: '600',
                        }}>
                        +
                      </Text>
                    </Pressable>
                  </Pressable>
                  {console.log('aditys5')}
                  <Text style={{fontSize: 16, fontWeight: 'bold'}}>
                    ₹{item.price * item.quantity}
                  </Text>
                </View>
              ))}
            </View>

            <View style={{padding: 10}}>
              <Text style={{fontSize: 16, fontWeight: '600'}}>
                Delivery Instructions
              </Text>
              <ScrollView
                horizontal
                style={{marginTop: 10}}
                showsHorizontalScrollIndicator={false}>
                {instructions.map((item, i) => (
                  <Pressable
                    style={{
                      margin: 10,
                      borderRadius: 10,
                      padding: 10,
                      backgroundColor: 'white',
                    }}>
                    <View style={{alignItems: 'center'}}>
                      <Image
                        source={item.image}
                        style={{height: 25, width: 25}}
                      />
                      <Text
                        style={{
                          width: 75,
                          fontSize: 13,
                          color: '#383838',
                          paddingTop: 10,
                          textAlign: 'center',
                        }}>
                        {item.name}
                      </Text>
                    </View>
                  </Pressable>
                ))}
              </ScrollView>
            </View>

            <View style={{marginHorizontal: 10}}>
              <Text style={{fontSize: 16, fontWeight: 'bold'}}>
                Billing Details
              </Text>
              <View
                style={{
                  backgroundColor: 'white',
                  borderRadius: 7,
                  padding: 10,
                  marginTop: 15,
                }}>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}>
                  <Text
                    style={{fontSize: 18, fontWeight: '400', color: 'gray'}}>
                    Item Total
                  </Text>
                  <Text style={{fontSize: 18, fontWeight: '400'}}>
                    ₹{total}
                  </Text>
                </View>
                {console.log('aditys8')}
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginVertical: 8,
                  }}>
                  <Text
                    style={{fontSize: 18, fontWeight: '400', color: 'gray'}}>
                    Delivery Fee | 1.2KM
                  </Text>
                  <Text
                    style={{
                      fontSize: 18,
                      fontWeight: '400',
                      color: '#FF4500',
                    }}>
                    FREE
                  </Text>
                </View>
                {console.log('aditys9')}
                <View style={{flexDirection: 'row', alignItems: 'center'}}>
                  <Text
                    style={{fontSize: 18, fontWeight: '500', color: 'gray'}}>
                    Free Delivery on Your order
                  </Text>
                </View>

                <View
                  style={{
                    borderColor: 'gray',
                    height: 1,
                    borderWidth: 0.5,
                    marginTop: 10,
                  }}
                />
                {console.log('aditys10')}
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginVertical: 10,
                  }}>
                  <Text
                    style={{fontSize: 18, fontWeight: '500', color: 'gray'}}>
                    Delivery Tip
                  </Text>
                  <Text
                    style={{
                      fontSize: 18,
                      fontWeight: '400',
                      color: '#FF4500',
                    }}>
                    ADD TIP
                  </Text>
                </View>

                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                  }}>
                  <Text
                    style={{fontSize: 18, fontWeight: '500', color: 'gray'}}>
                    Taxes and Charges
                  </Text>
                  {console.log('aditys11')}
                  <Text
                    style={{
                      fontSize: 18,
                      fontWeight: '400',
                      color: '#FF4500',
                    }}>
                    95
                  </Text>
                </View>

                <View
                  style={{
                    borderColor: 'gray',
                    height: 1,
                    borderWidth: 0.5,
                    marginTop: 10,
                  }}
                />

                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    marginVertical: 8,
                  }}>
                  <Text style={{fontSize: 18, fontWeight: 'bold'}}>To Pay</Text>
                  <Text style={{fontSize: 18, fontWeight: 'bold'}}>
                    {total + 95}
                  </Text>
                </View>
              </View>
            </View>
          </>
        ) : (
          <View
            style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
            <Text
              style={{textAlign: 'center', fontSize: 16, fontWeight: '600'}}>
              Your Cart is Empty!
            </Text>
          </View>
        )}
      </ScrollView>
      {console.log('aditys12')}
      {total === 0 ? null : (
        <Pressable
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
            backgroundColor: 'white',
            marginBottom: 20,
            padding: 20,
          }}>
          <View>
            <Text style={{fontSize: 18, fontWeight: '600'}}>₹{total + 95}</Text>
            <Text style={{color: '#00A877', fontSize: 17}}>
              View Detailed Bill
            </Text>
          </View>
          {console.log('aditys13')}
          <Pressable
            onPress={() => {
              navigation.navigate('Loading');
              dispatch(cleanCart());
            }}
            style={{
              backgroundColor: '#00A877',
              padding: 14,
              width: 150,
              borderRadius: 6,
            }}>
            <Text
              style={{
                color: 'white',
                fontSize: 16,
                fontWeight: 'bold',
                textAlign: 'center',
              }}>
              Proceed To pay
            </Text>
          </Pressable>
        </Pressable>
      )}
    </>
  );
};

export default CartScreen;
