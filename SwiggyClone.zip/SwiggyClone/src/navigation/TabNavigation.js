import {View, Text} from 'react-native';
import React, {useEffect, useState} from 'react';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {NavigationContainer} from '@react-navigation/native';
import Home from '../screen/Home';
import SpashScreen from '../screen/SpashScreen';
import MenuScreen from '../screen/MenuScreen';
import CartScreen from '../screen/CartScreen';

const TabNavigation = () => {
  const Stack = createNativeStackNavigator();

  const [splashScreen, setSplashScreen] = useState(true);

  useEffect(() => {
    setTimeout(() => {
      setSplashScreen(false);
    }, 1000);
  }, []);
  
  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{headerShown: false}}>
        {splashScreen ? (
          <Stack.Screen name={'SpashScreen'} component={SpashScreen} />
        ) : null}
        <Stack.Screen name={'Home'} component={Home} />
        <Stack.Screen name={'MenuScreen'} component={MenuScreen} />
        <Stack.Screen name={'CartScreen'} component={CartScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default TabNavigation;
